<?php
include('conexion.php');
$con = conexion();

$sql = "SELECT * FROM i201";
$query = mysqli_query($con, $sql);

$sql1 = "SELECT * FROM a201";
$query1 = mysqli_query($con, $sql1);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <nav>
        <section class="titulo-nav"><h1></h1></section>
    </nav>
    <main>
        <section class="informacion">
            <div class="informacion-container">
                <div class="informacion-titulo"><h3>INFORMACION DEL GRUPO</h3></div>
                <div class="informacion-subcontainer">
                    <div class="informacion-tablas">
                    <div class="informacion-tabla">
                    <table>
                    <?php while ($row = mysqli_fetch_array($query)):?>
                  
                            <td style="text-align: left;">
                                <?=$row['grupo'] ?><br>
                                <?=$row['especialidad'] ?><br>
                                <?= $row['alumnos'] ?>
                            </td>
                    </table>
                    </div>
                    
                    <div class="informacion-tabla1">
                    <table>
                            <td style="text-align: left; vertical-align: middle;">
                                <?= $row['tutor'] ?><br>
                                <?= $row['jefe'] ?><br>
                                <?= $row['subjefe'] ?>
                            </td>
                    <?php endwhile; ?>
                    </table>
                    </div>
                    </div>
                    <div class="informacion-boton"> <a href="agregaralumno.php"><input type="button" value="AGREGAR ALUMNO"></a></div>
                </div>
            </div>
        </section>
        <section class="grupos">
            <table>
                <thead>
                    <th class="nl">N/L</th>
                    <th class="nombre">NOMBRE</th>
                    <th class="apellidop">APELLIDO PATERNO</th>
                    <th class="apellidom">APELLIDO MATERNO</th>
                    <th class="matricula">MATRICULA</th>
                    <th class="datos"></th>
                </thead>
                <tbody>
                <?php while ($row = mysqli_fetch_array($query1)): ?>
                    
                    <th><?= $row['id'] ?></th>
                    <th><?= $row['nombre'] ?></th>
                    <th><?= $row['apellidop'] ?></th>
                    <th><?= $row['apellidom'] ?></th>
                    <th><?= $row['matricula'] ?></th>

                    <th><a href="editaralumno201.php?id=<?= $row['id']?>"><div class="opciones-container">
                        <div class="info-grupo"></div>
                    </div></a></th>
                    <tr>
                    <?php endwhile; ?>
            
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>